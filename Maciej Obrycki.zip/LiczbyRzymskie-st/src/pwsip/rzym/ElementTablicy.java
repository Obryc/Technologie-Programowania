package pwsip.rzym;

public class ElementTablicy {
    String rzymska;
    int arabska;

    public ElementTablicy(String rzymska, int arabska) {
        this.rzymska = rzymska;
        this.arabska = arabska;
    }

    public String getRzymska() {
        return rzymska;
    }

    public void setRzymska(String rzymska) {
        this.rzymska = rzymska;
    }

    public int getArabska() {
        return arabska;
    }

    public void setArabska(int arabska) {
        this.arabska = arabska;
    }
}
