package pwsip.rzym;

public class LiczbaRzymska {
    private String napis = "";
    private boolean format = true;
    private int min = 0;
    private int max = 3999;
    private static String[] rzymskie = {"M", "CM", "D", "CD", "C", "XC", "L", "XL", "X", "IX", "V", "IV", "I"};
    private static int[] arabskie = {1000, 900, 500, 400, 100, 90, 50, 40, 10, 9, 5, 4, 1};

    public LiczbaRzymska() {

    }

    public LiczbaRzymska(String napis) {
        this.napis = napis;
    }


    @Override
    public String toString() {
        return napis;
    }


    public int rzymska2arabska() {
        String liczba = napis;
        String input;
        input = liczba;
        int wyjscie = 0;
        liczba = liczba.toUpperCase();

        int index = 0;
        for (int i = 0; i < rzymskie.length; i++) {
            while (liczba.startsWith(rzymskie[i], index)) {
                wyjscie =wyjscie + arabskie[i];
                index += rzymskie[i].length();
            }
        }

        return wyjscie;
    }

    public static LiczbaRzymska arabska2Rzymska(int num) {

        System.out.println("arabska: " + num);
        int[] values = {1000,900,500,400,100,90,50,40,10,9,5,4,1};
        String[] romanLiterals = {"M","CM","D","CD","C","XC","L","XL","X","IX","V","IV","I"};

        StringBuilder roman = new StringBuilder();

        for(int i=0;i<values.length;i++) {
            while(num >= values[i]) {
                num -= values[i];
                roman.append(romanLiterals[i]);
            }
        }
        System.out.println("rzymska: " + roman.toString());
        return null;
    }

    public void setFormat(boolean format) {
        this.format = format;
    }

    public void wyswietl()
    {
        if (format)
            System.out.println(napis);
        else
            System.out.println(this.rzymska2arabska());
    }
}
